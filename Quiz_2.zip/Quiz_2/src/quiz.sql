-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2023 at 09:04 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `Id` int(11) NOT NULL,
  `question` varchar(100) DEFAULT NULL,
  `option1` varchar(50) DEFAULT NULL,
  `option2` varchar(50) DEFAULT NULL,
  `option3` varchar(50) DEFAULT NULL,
  `option4` varchar(50) DEFAULT NULL,
  `answer` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`Id`, `question`, `option1`, `option2`, `option3`, `option4`, `answer`) VALUES
(1, 'What is part of a database that holds only one type of information?', 'Report', 'Field', 'Record', 'File', 'Field'),
(2, 'OS\' computer abbreviation usually means ?', 'Order of Significance', 'Open Software', 'Operating System', 'Optical Sensor', 'Operating System'),
(3, 'Which is a reserved word in the Java programming language?', 'method', 'native', 'reference', ' subclasses ', 'native'),
(4, 'Which is a valid keyword in java?\n', 'interface', 'string', 'Float', 'unsigned', 'interface'),
(5, 'By default a real number is treated as a', ' float ', ' double ', 'long double', 'far double', ' double '),
(6, 'The power to decide an election petition is vested in the', 'Parliament', 'Supreme Court', 'High courts', 'Election Commission', 'High courts'),
(7, 'The members of Lok Sabha hold office for a term of', '4 years', '5 years', '6 years', '3 years', '5 years'),
(8, 'The minimum age to qualify for election to the Lok Sabha is', '25 years', '21 years', '18 years', '35 years', '21 years'),
(9, 'The minimum age of the voter in India is', '25 years', '21 years', '18 years', '15 years', '18 years'),
(10, 'The office of the president can fall vacant due to', 'resignation', 'removal', 'death', 'All of the above', 'All of the above');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `Rollno` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `FatherName` varchar(100) NOT NULL,
  `MotherName` varchar(100) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `Contctno` bigint(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `10thBoard` varchar(50) NOT NULL,
  `10Percent` varchar(50) NOT NULL,
  `10Passout` varchar(50) NOT NULL,
  `12Board` varchar(50) NOT NULL,
  `12Percent` varchar(50) NOT NULL,
  `12Passout` varchar(50) NOT NULL,
  `GraduationUniv` varchar(50) NOT NULL,
  `Grduationpercent` varchar(50) NOT NULL,
  `GraduationPassout` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `Marks` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`Rollno`, `Name`, `FatherName`, `MotherName`, `Gender`, `Contctno`, `Email`, `10thBoard`, `10Percent`, `10Passout`, `12Board`, `12Percent`, `12Passout`, `GraduationUniv`, `Grduationpercent`, `GraduationPassout`, `address`, `Marks`) VALUES
(101, 'Anurag', 'Ankit', 'Dipti', 'Male', 9986654111, 'Anu@gmail.com', 'CBSE', '70', '2018', 'CBSE', '75', '2020', 'LU', '72', '2023', 'Ballia', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`Rollno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `Rollno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
