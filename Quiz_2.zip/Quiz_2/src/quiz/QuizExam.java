/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz;
import Project.ConnectionProvider;
import java.sql.*;
import java .awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java .util.Date;
import javax.swing.JOptionPane;
import javax.swing.Timer;
 
/**
 *
 * @author HP-PC
 */
public class QuizExam extends javax.swing.JFrame {
     public String QuestionId="1";
     public String answer;
     public int min=00;
     public int sec=00;
     public int marks=0;
     
     public void answerCheck(){
         String studentAnswer="";
         if(rb1.isSelected())
         {
             studentAnswer=rb1.getText();
         }
         else if(rb2.isSelected())
         {
             studentAnswer=rb2.getText();
         }
         else if(rb3.isSelected())
         {
             studentAnswer=rb3.getText();
         }
         else
         {
             studentAnswer=rb4.getText();
         }
         if(studentAnswer.equals(answer))
         {
             marks=marks+1;
             String marks1=String.valueOf(marks);
            //int m=marks;
             mk.setText(marks1);
         }
         else
         {
             
         }
            
         int questionid1=Integer.parseInt(QuestionId);
         questionid1=questionid1+1;
        
         QuestionId=String.valueOf(questionid1);
         rb1.setSelected(false);
         rb2.setSelected(false);
            rb3.setSelected(false);
            rb4.setSelected(false);
            
         
         
     }
     public void question(){
         try{
        Connection con=ConnectionProvider.getCon();
        Statement st=con.createStatement();
        
        ResultSet rs1=st.executeQuery("select * from question where id='"+QuestionId+"'");
       while(rs1.next())
       {
           qn.setText(rs1.getString(1));
           qd.setText(rs1.getString(2));
           rb1.setText(rs1.getString(3));
           rb2.setText(rs1.getString(4));
           rb3.setText(rs1.getString(5));
           rb4.setText(rs1.getString(6));
           answer=rs1.getString(7);
           
       }            
    }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(this,ex);
            
        }
        int j=Integer.parseInt(qn.getText());
        if(j==10)
        {
            CmdNext.setVisible(false);
        }
         
     }
     
     public void submit(){
         answerCheck();
         String rollno=rbl.getText();
         try{
             Connection con=ConnectionProvider.getCon();
             Statement st=con.createStatement();
             st.executeUpdate("update student set marks='"+marks+"'where rollno='"+rollno+"'");
             String marks1=String.valueOf(marks);
             setVisible(false);
             new Submit(marks1).setVisible(true);
         }
         catch(Exception ex)
         {
             JOptionPane.showMessageDialog(this, ex);
         }
     }
     
     
    /**
     * Creates new form QuizExam
     */
    public QuizExam(String rollno) {
        initComponents();
        SimpleDateFormat dform=new SimpleDateFormat("dd-MM-yyyy");
         Date date=new Date();
        dt.setText(dform.format(date));
        rbl.setText(rollno);
        try{
        Connection con=ConnectionProvider.getCon();
        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery("select * from student where rollno='"+rollno+"'");
        while(rs.next())
        {
            nm.setText(rs.getString(2));
        }
        ResultSet rs1=st.executeQuery("select * from question where id='"+QuestionId+"'");
       while(rs1.next())
       {
           qn.setText(rs1.getString(1));
           qd.setText(rs1.getString(2));
           rb1.setText(rs1.getString(3));
           rb2.setText(rs1.getString(4));
           rb3.setText(rs1.getString(5));
           rb4.setText(rs1.getString(6));
           answer=rs1.getString(7);
           
       }            
    }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(this,ex);
        }
        setLocationRelativeTo(this);
        time=new Timer(1000,new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                sc.setText(String.valueOf(sec));
                mn.setText(String.valueOf(min));
                if(sec==60)
        {
            sec=00;
            min++;
            if(min==10)
            {
            time.stop();
            answerCheck();
            submit();
            }
        }
                sec++;
            }
        });
        time.start();
    }
    Timer time;
    public QuizExam() {
        initComponents();
         
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        dt = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        mn = new javax.swing.JLabel();
        sc = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        sc1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        rbl = new javax.swing.JLabel();
        nm = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        qn = new javax.swing.JLabel();
        mk = new javax.swing.JLabel();
        qd = new javax.swing.JLabel();
        rb1 = new javax.swing.JRadioButton();
        rb2 = new javax.swing.JRadioButton();
        rb3 = new javax.swing.JRadioButton();
        rb4 = new javax.swing.JRadioButton();
        CmdNext = new javax.swing.JButton();
        CmdSbt = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 255, 255));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/index student.png"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Algerian", 1, 50)); // NOI18N
        jLabel2.setText("Welcome");

        jLabel3.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        jLabel3.setText("Date");

        dt.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        dt.setText("jLabel4");

        jLabel5.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        jLabel5.setText("Total Time:");

        jLabel6.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        jLabel6.setText("Time Taken");

        jLabel7.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        jLabel7.setText("10");

        mn.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        mn.setForeground(new java.awt.Color(255, 0, 51));
        mn.setText("00");

        sc.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        sc.setForeground(new java.awt.Color(255, 0, 51));
        sc.setText("00");

        sc1.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        sc1.setForeground(new java.awt.Color(255, 0, 51));
        sc1.setText(":");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(161, 161, 161)
                .addComponent(jLabel3)
                .addGap(40, 40, 40)
                .addComponent(dt)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 323, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(jLabel7))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addComponent(mn)
                        .addGap(7, 7, 7)
                        .addComponent(sc1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(sc)))
                .addGap(38, 38, 38))
            .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(dt)
                    .addComponent(jLabel5)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(mn)
                    .addComponent(sc)
                    .addComponent(sc1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 140));

        jPanel2.setBackground(new java.awt.Color(51, 255, 255));

        jLabel10.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        jLabel10.setText("Roll no");

        jLabel11.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        jLabel11.setText("Name");

        jLabel12.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        jLabel12.setText("Total Question");

        jLabel13.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        jLabel13.setText("Question No");

        jLabel14.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        jLabel14.setText("Marks");

        rbl.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        rbl.setText("101");

        nm.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        nm.setText("Abhishek");

        jLabel17.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        jLabel17.setText("10");

        qn.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        qn.setText("00");

        mk.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        mk.setText("00");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(60, 60, 60)
                        .addComponent(rbl, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel14)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(mk))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel13)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(qn))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel12)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel17)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGap(49, 49, 49)
                        .addComponent(nm, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(78, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(rbl))
                .addGap(51, 51, 51)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(nm))
                .addGap(39, 39, 39)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(jLabel17))
                .addGap(38, 38, 38)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(qn))
                .addGap(35, 35, 35)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(mk))
                .addContainerGap(318, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 138, 410, 630));

        qd.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        qd.setText("Question Demo");
        getContentPane().add(qd, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 230, 810, -1));

        rb1.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        rb1.setText("jRadioButton1");
        rb1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb1ActionPerformed(evt);
            }
        });
        getContentPane().add(rb1, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 340, -1, -1));

        rb2.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        rb2.setText("jRadioButton2");
        rb2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb2ActionPerformed(evt);
            }
        });
        getContentPane().add(rb2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 420, -1, -1));

        rb3.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        rb3.setText("jRadioButton3");
        rb3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb3ActionPerformed(evt);
            }
        });
        getContentPane().add(rb3, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 490, -1, -1));

        rb4.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        rb4.setText("jRadioButton4");
        rb4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb4ActionPerformed(evt);
            }
        });
        getContentPane().add(rb4, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 560, -1, -1));

        CmdNext.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        CmdNext.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Next.png"))); // NOI18N
        CmdNext.setText("Next");
        CmdNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CmdNextActionPerformed(evt);
            }
        });
        getContentPane().add(CmdNext, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 650, -1, -1));

        CmdSbt.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        CmdSbt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/save.png"))); // NOI18N
        CmdSbt.setText("Submit");
        CmdSbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CmdSbtActionPerformed(evt);
            }
        });
        getContentPane().add(CmdSbt, new org.netbeans.lib.awtextra.AbsoluteConstraints(1220, 660, -1, -1));

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pages background student.jpg"))); // NOI18N
        getContentPane().add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1370, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CmdNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmdNextActionPerformed
        // TODO add your handling code here:
        
         
         
                 
                 
        answerCheck(); 
        question();
        
    }//GEN-LAST:event_CmdNextActionPerformed

    private void CmdSbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmdSbtActionPerformed
        // TODO add your handling code here:
        int a=JOptionPane.showConfirmDialog(this,"Do you really want to submit","select",JOptionPane.YES_NO_OPTION);
        if(a==0)
        {
            answerCheck();
            submit();
        }
    }//GEN-LAST:event_CmdSbtActionPerformed

    private void rb1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb1ActionPerformed
        // TODO add your handling code here:
        if(rb1.isSelected())
        {
            rb2.setSelected(false);
            rb3.setSelected(false);
            rb4.setSelected(false);
            
        }
    }//GEN-LAST:event_rb1ActionPerformed

    private void rb2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb2ActionPerformed
        // TODO add your handling code here:
         if(rb2.isSelected())
        {
            rb1.setSelected(false);
            rb3.setSelected(false);
            rb4.setSelected(false);
            
        }
    }//GEN-LAST:event_rb2ActionPerformed

    private void rb3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb3ActionPerformed
        // TODO add your handling code here:
         if(rb3.isSelected())
        {
            rb1.setSelected(false);
            rb2.setSelected(false);
            rb4.setSelected(false);
            
        }
    }//GEN-LAST:event_rb3ActionPerformed

    private void rb4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb4ActionPerformed
        // TODO add your handling code here:
         if(rb4.isSelected())
        {
            rb2.setSelected(false);
            rb3.setSelected(false);
            rb1.setSelected(false);
            
        }
        
    }//GEN-LAST:event_rb4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QuizExam.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QuizExam.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QuizExam.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QuizExam.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new QuizExam().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CmdNext;
    private javax.swing.JButton CmdSbt;
    private javax.swing.JLabel dt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel mk;
    private javax.swing.JLabel mn;
    private javax.swing.JLabel nm;
    private javax.swing.JLabel qd;
    private javax.swing.JLabel qn;
    private javax.swing.JRadioButton rb1;
    private javax.swing.JRadioButton rb2;
    private javax.swing.JRadioButton rb3;
    private javax.swing.JRadioButton rb4;
    private javax.swing.JLabel rbl;
    private javax.swing.JLabel sc;
    private javax.swing.JLabel sc1;
    // End of variables declaration//GEN-END:variables
}
